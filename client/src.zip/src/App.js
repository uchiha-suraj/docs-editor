import * as React from 'react';
import { DocumentEditorContainerComponent, Toolbar } from '@syncfusion/ej2-react-documenteditor';
DocumentEditorContainerComponent.Inject(Toolbar);
export default class App extends React.Component {
    render() {
        return (<DocumentEditorContainerComponent id="container" style={{ 'height': '1080px' }} serviceUrl="https://ej2services.syncfusion.com/production/web-services/api/documenteditor/" enableToolbar={true}/>);
    }
}


// import React from 'react';
// import TextEditor from './TextEditor';

// const App = () => {
//   return (
//     <TextEditor />
//   )
// }

// export default App